$(document).on("mobileinit", function()
{
   $.mobile.ajaxEnabled = false;
});
